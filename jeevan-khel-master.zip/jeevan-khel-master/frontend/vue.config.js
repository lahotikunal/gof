module.exports = {
    transpileDependencies: ['vuetify'],
};
